def verify(*args, **kwargs):
 raise ArithmeticError('unit own publication is not verified')
