import importlib.util,json,sys,time
from pathlib import Path
w=Path(__file__).resolve().parent.parent
spec=importlib.util.spec_from_file_location("tested_outer_operator",w/"run-source-budget-v2-collection.py");m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
f=Path(__file__).resolve().parent/"before-fix"
f.mkdir()
r=m.run([sys.executable,"-c","pass"],f/"exhausted",.01,preflight=lambda:time.sleep(.03))
print(json.dumps(r),flush=True)
assert r["pid"] is None and r["returncode"]==124,"exhausted preflight must refuse launch"
