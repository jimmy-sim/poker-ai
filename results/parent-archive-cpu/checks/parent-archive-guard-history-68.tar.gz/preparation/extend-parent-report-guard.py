from pathlib import Path
import ast,shutil,json,hashlib
w=Path('work');history=w/'parent-archive-guard-history-68';history.mkdir(exist_ok=False)
for name in ['check-parent-archive-report.py','check-parent-archive-guard-setup.py','parent-archive-final-operator-map.json']+[f'parent-archive-guard-setup-{minor}{suffix}' for minor in ('311','312') for suffix in ('.json','.log')]:
 shutil.copyfile(w/name,history/name)
 if name.startswith('parent-archive-guard-setup-'): (w/name).unlink()
p=w/'check-parent-archive-report.py';s=p.read_text();needle=" 'profile_parent_archive.synthetic_tree',\n";assert needle in s
extra=['poker_ai.evaluation.compact_fixed_inputs.decode','poker_ai.evaluation.compact_sampled_inputs.contexts','poker_ai.postflop.compact_full_artifacts.capture','poker_ai.postflop.compact_full_artifacts.metrics','poker_ai.postflop.compact_full_context.metrics']
s=s.replace(needle,needle+''.join(' '+repr(n)+',\n' for n in extra));p.write_text(s)
t=ast.parse(s);names=ast.literal_eval(next(n.value for n in t.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='blocked' for x in n.targets)));assert len(names)==73 and len(set(names))==73
p=w/'check-parent-archive-guard-setup.py';s=p.read_text().replace('len(blocked)==68','len(blocked)==73').replace('all68_guard','all73_guard');p.write_text(s)
(history/'manifest.json').write_text(json.dumps(dict(scope='Earlier successful 68-target guard setup retained before adding five identified capture/metric/helper aliases; no raw pair or numerical report existed',files=[dict(file=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(history.iterdir())]),indent=2)+'\n')
