"""Real tiny process fixtures, never poker or formal data collection."""
import importlib.util,json,subprocess,sys,tempfile,time
from pathlib import Path
W=Path(__file__).resolve().parent
p=W/'run-checkpoint-observer-collection.py';spec=importlib.util.spec_from_file_location('observer_operator_fixture',p)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
folder=W/'checkpoint-observer-operator-fixtures';folder.mkdir(exist_ok=False)
rows=[]
for kind,code in [('success',0),('nonzero',7)]:
 dest=folder/kind
 command=[sys.executable,'-c','import pathlib,sys; pathlib.Path(sys.argv[1]).mkdir(); (pathlib.Path(sys.argv[1])/"raw.txt").write_bytes(b"fixture"); sys.exit(int(sys.argv[2]))',str(dest),str(code)]
 actual=m.run(command,dest,10);assert actual['returncode']==code
 try:m.run(command,dest,10)
 except FileExistsError:pass
 else:raise AssertionError('existing output accepted')
 rows.append(dict(case=kind,returncode=actual['returncode'],status=actual['status']))
for kind,cap,command in [
 ('timeout',.25,[sys.executable,'-c','import pathlib,sys,time; pathlib.Path(sys.argv[1]).mkdir(); (pathlib.Path(sys.argv[1])/"partial.bin").write_bytes(b"partial"); time.sleep(10)',str(folder/'timeout')]),
 ('interrupt',10,[sys.executable,'-c','import pathlib,sys,signal,os; pathlib.Path(sys.argv[1]).mkdir(); os.kill(os.getppid(),signal.SIGINT)',str(folder/'interrupt')])]:
 actual=m.run(command,folder/kind,cap)
 assert actual['returncode']==(124 if kind=='timeout' else 130) and actual['status']=='failed_retained'
 rows.append(dict(case=kind,returncode=actual['returncode'],status=actual['status']))
assert (folder/'timeout/partial.bin').read_bytes()==b'partial'
(folder/'checks.json').write_text(json.dumps(dict(status='all_four_real_process_operator_fixtures_pass',fixtures=rows,scope='Tiny subprocess behavior only; fixture caps do not replace scientific caps.'),indent=2)+'\n')
print(json.dumps(rows))
